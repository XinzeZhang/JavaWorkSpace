package core;

import java.io.IOException;

//import java.util.Scanner;

public class Main
	{

		public static void main(String[] args) throws IOException
			{

				String[] arg = { "/home/xinze/Documents/EclipseWorkspace/demo/src/trainfile/data_train.txt", // 
						"/home/xinze/Documents/EclipseWorkspace/demo/src/trainfile/model_r.txt" }; // 
													
				String[] parg = { "/home/xinze/Documents/EclipseWorkspace/demo/src/trainfile/data_test.txt", // 
						"/home/xinze/Documents/EclipseWorkspace/demo/src/trainfile/model_r.txt", // 
						"/home/xinze/Documents/EclipseWorkspace/demo/src/trainfile/out_r.txt" }; // 
				System.out.println("........SVM.........."); // 
				svm_train t = new svm_train(); // 
				svm_predict p = new svm_predict();
				t.main(arg); // µ÷ÓÃ
				p.main(parg); // µ÷ÓÃ
				System.out.println("........SVM..........");

			}

	}